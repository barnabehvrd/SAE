
Pour l'installation de l'application, vous avez le choix entre 2 options concernant les identifiants de la base de données

- option 1 : vous décidez du nom de l'utilisateur Mysql, de celui de votre base de donnée et du mot de passe de l'utilisateur MySQL

- option 2 : vous conservez les identifiants déjà existants

1. Option 1  
Si vous souhaitez définir vos propres identifiants pour la base de données, récupérez les fichiers  
`ids.txt` et `setIds.sh`  
`setIds.sh` va remplacer tous les identifiants présents dans tous les fichiers php

	- Créez votre base de donnée en lui donnant le nom que vous voulez

	- Assurez vous que le fichier `setIds.sh` possède bien un droit en exécution

	- Placez vos identifiants dans le fichier `ids.txt` en remplaçant les valeurs des 4 premières lignes.

	- Placez ensuite les fichiers `ids.txt` et `setIds.sh` dans le dossier principal de l'application

	- Exécutez setIds.sh (pour remplacer tous les identifinats) avec
```bash
$ ./setIds.sh
```

- La base de données une fois créée peut être alimentée avec le fichier `gestionDB.sql` sous phpmyadmin ou depuis le terminal avec
```bash
$ mysql -u utilisateur -p < gestionDB.sql
```


2. Option 2  
Enfin, si vous souhaitez installer l'application Web sous XAMPP, sans rien changer aux identifiants déjà en place, suivez les instructions données  ici : 

<https://docs.google.com/document/d/1TWRei5tZhCpDdAvufN2YUJNev7qF2n1zJmF3wDluFyY/edit?tab=t.0>